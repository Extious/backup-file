#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define DEVICE_NAME "/dev/mydevice"

int main()
{
    int fd;
    char *buffer;
    buffer = (char*)malloc(32*sizeof(char));

    // 打开设备文件
    fd = open(DEVICE_NAME, O_RDWR);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }
    int n;
    // 读取数据
    read(fd, buffer, 16);
    printf("%s",buffer);
    
    // 关闭设备文件
    close(fd);
    return 0;
}
