#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linuxev.h>
#include <linuxifo.h>
#include <linux/uaccess.h>
#include <linux/wait.h>




MODULE_LICENSE("GPL");

#define DEVICE_NAME "mydevice"
#define BUFFER_SIZE 32
#define MAJOR_NUMBER 111

static struct kfifo buffer;
static size_t pread_idx;

static size_t pwrite_idx;
static wait_queue_head_t read_queue;
static wait_queue_head_t write_queue;
struct semaphore read_sem,write_sem;



static int mydevice_open(struct inode *inodep, struct file *filep)
{
    printk(KERN_INFO "mydevice: opening device\n");
    return 0;
}

static int mydevice_release(struct inode *inodep, struct file *filep)
{
    printk(KERN_INFO "mydevice: closing device\n");
    return 0;
}


// 读操作
static ssize_t mydevice_read(struct file *filep, char __user *buf, size_t count, loff_t *pos)
{

    //unsigned char data[32];
    ssize_t ret_count = 0;
    unsigned int copied = 0;
    int ret;
    down_interruptible(&read_sem);   
    if (kfifo_len(&buffer) < count) 
    {
        if (filep->f_flags & O_NONBLOCK) 
        {
            return -EAGAIN;
        }
        printk(KERN_INFO "mydevice: process %i (%s) going to sleep\n", current->pid, current->comm);
        while(kfifo_len(&buffer) < count){
            ret = wait_event_interruptible(read_queue, !(kfifo_len(&buffer) < count));
        }
        if (ret) {
            return ret;
        }
        printk(KERN_INFO "mydevice:read process %i (%s) woken up\n", current->pid, current->comm);
    }

    ret = kfifo_to_user(&buffer, buf, count, &copied);
    //printk("mydevice:read:%s",buf);
    //unsigned int n = kfifo_out(&buffer, data, count);
    printk(KERN_INFO "mydevice get data: %d\n", copied);
    if (ret) 
    {
        return ret;
    }
    wake_up_interruptible(&write_queue);
    
    up(&read_sem);
    
    return ret_count;
    
}


// 写操作


static ssize_t mydevice_write(struct file *filep, const char __user *buf, size_t count, loff_t *pos) 
{
    int ret;
    unsigned int copied;
    down_interruptible(&write_sem);
    if ((BUFFER_SIZE - kfifo_len(&buffer)) < count) 
    {
        if (filep->f_flags & O_NONBLOCK) 
        {
            return -EAGAIN;
        }
        printk(KERN_INFO "mydevice:write process %i (%s) going to sleep\n", current->pid, current->comm);
        while((BUFFER_SIZE - kfifo_len(&buffer)) < count){
            ret = wait_event_interruptible(write_queue, !((BUFFER_SIZE - kfifo_len(&buffer)) < count));
        }
        if (ret) 
        {
            return ret;
        }
        printk(KERN_INFO "mydevice:write process %i (%s) woken up\n", current->pid, current->comm);
    }

    ret = kfifo_from_user(&buffer, buf, count, &copied);
    //unsigned int n = kfifo_in(&buffer, buf, count);
    printk(KERN_INFO "mydevice put %d bytes data\n", copied);
    if (ret) 
    {
        return ret;
    }
    wake_up_interruptible(&read_queue);
    up(&write_sem);
    return copied;
}


static const struct file_operations mydevice_fops = {
    .owner = THIS_MODULE,
    .open = mydevice_open,
    .release = mydevice_release,
    .read = mydevice_read,
    .write = mydevice_write,
};


static dev_t dev_num;
static struct cdev my_cdev;

static int __init mydevice_init(void)
{

   
    
    
    int ret;
    dev_num = MKDEV(MAJOR_NUMBER,0);
    ret = register_chrdev_region(dev_num, 1, DEVICE_NAME);
    if (ret < 0) 
    {
        printk(KERN_ALERT "mydevice: failed to register a major number\n");
        return ret;
    }
    int major = MAJOR_NUMBER;
    printk(KERN_INFO "mydevice: registered with major number %d\n", major);

    init_waitqueue_head(&read_queue);
    init_waitqueue_head(&write_queue);

    ret = kfifo_alloc(&buffer, BUFFER_SIZE, GFP_KERNEL);
    if (ret) 
    {
        printk(KERN_ALERT "mydevice: failed to allocate kfifo\n");
        unregister_chrdev_region(dev_num, 1);
        return ret;
    }

    cdev_init(&my_cdev, &mydevice_fops);
    my_cdev.owner = THIS_MODULE;
    ret = cdev_add(&my_cdev, dev_num, 1);
    if (ret) 
    {
        printk(KERN_ALERT "mydevice: failed to add cdev\n");
        kfifo_free(&buffer);
        unregister_chrdev_region(dev_num, 1);
        return ret;
    }
    sema_init(&write_sem,1);
    sema_init(&read_sem,1);

    return 0;
}


static void __exit mydevice_exit(void)
{
    // 释放缓冲区
    kfifo_free(&buffer);

    // 删除设备
    cdev_del(&my_cdev);

    // 注销设备号
    unregister_chrdev_region(dev_num, 1);

    printk(KERN_INFO "mydevice: unloaded\n");
}

module_init(mydevice_init);
module_exit(mydevice_exit);
