#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define DEVICE_NAME "/dev/mydevice"

int main()
{
    int fd,n=1;
    char buffer[32];
    // 打开设备文件
    fd = open(DEVICE_NAME, O_RDWR);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    write(fd, "1234567890", 10);



    // 关闭设备文件
    close(fd);

    return 0;
}
